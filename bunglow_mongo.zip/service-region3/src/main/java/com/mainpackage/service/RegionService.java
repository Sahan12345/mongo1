package com.mainpackage.service;

import com.mainpackage.model.Region;
import com.mainpackage.repository.RegionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegionService {

    @Autowired
    public RegionRepository regionRepository;

    public List<Region> getAllRegions() {
        return  regionRepository.findAll();
    }

    public void updateRegion(Region region){
        regionRepository.save(region);
    }

    public void addRegion(Region region){
        regionRepository.save(region);
    }

    public void deleteRegion(Region region){
        regionRepository.delete(region);
    }

}
