package com.mainpackage.repository;

import com.mainpackage.model.Region;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface RegionRepository extends MongoRepository<Region,String>{


}
