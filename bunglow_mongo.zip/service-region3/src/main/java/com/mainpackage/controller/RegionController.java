package com.mainpackage.controller;

import com.mainpackage.model.Region;
import com.mainpackage.service.RegionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RegionController {

    @Autowired
    private RegionService regionService;

    @RequestMapping(value = "/regions")
    public List<Region> getAllRegions(){
        return regionService.getAllRegions();
    }

    @RequestMapping(value = "add-region", method = RequestMethod.POST)
    public String addRegion(@RequestBody Region region){
        regionService.addRegion(region);
        return "successfully added";
    }

    @RequestMapping(value = "/update-region", method=RequestMethod.PUT)
    public String updateRegion(@RequestBody Region region){
        regionService.updateRegion(region);
        return "successfully updated";
    }

    @RequestMapping(value="delete-region", method=RequestMethod.DELETE)
    public String deleteRegion(@RequestBody Region region){
        regionService.deleteRegion(region);
        return "deleted";
    }

}
